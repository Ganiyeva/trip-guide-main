import styled from "styled-components";
import { useTranslation } from 'react-i18next';

const HotelListCard = () => {

  const { t } = useTranslation();

  return (
    <div>hotelCard</div>
  );
};

export default HotelListCard;